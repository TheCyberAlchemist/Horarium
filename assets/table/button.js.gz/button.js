$(document).ready(function() {

  $('.addBut').click(function(){
    // console.log("HII");
    var addB = ""
    $('.tbooty').append(addB);
  });
  $('.addRow').sortable();
  // $('#removeRow').click(function(){
  //   $('tbody tr:last').remove();
});
